package com.keepcoding.dominio

//case class Geolocalizacion(latitud:Double, longitud:Double, ciudad:String, pais:String)
case class Geolocalizacion(ciudad: String)

case class Transaccion(DNI: Long, importe: Double, descripcion: String, categoria: String, tarjetaCredito: String,
                       geolocalizacion: Geolocalizacion)

case class Cliente(DNI: Long, nombre: String, cuentaCorriente: String)

//Jaime
case class FechaTransaccion(fecha: String, cuentaCorriente: String)
case class TransaccionFull(DNI: Long, importe: Double, descripcion: String, categoria: String, tarjetaCredito: String,
                           cuentaCorriente: String, geolocalizacion: Geolocalizacion)
