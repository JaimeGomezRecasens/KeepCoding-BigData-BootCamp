package com.keepcoding.batchlayer

import com.keepcoding.dominio._
import org.apache.spark.sql.SparkSession
import org.apache.spark.util.LongAccumulator


object MetricasSparkSQL {

  def run(args: Array[String]): Unit ={

    val sparkSession = SparkSession.builder().master(master="local[*]")
      .appName(name= "Práctica final - Batch layer - Spark SQL")
      .getOrCreate()

    import sparkSession.implicits._

    //val rddTransacciones = sparkSession.read.csv(path= s"file:///${args(0)}")
    val rddTransacciones = sparkSession.read.csv(path="/home/keepcoding/KeepCoding/Workspace/PracticaFinal/dataset/TransaccionesNew.csv")

    val cabecera = rddTransacciones.first

    val rddSinCabecera = rddTransacciones.filter(!_.equals(cabecera)).map(_.toString().split(","))

    val acumulador: LongAccumulator = sparkSession.sparkContext.longAccumulator(name ="dniCliente")
    val acumuladorTransaccion: LongAccumulator = sparkSession.sparkContext.longAccumulator( name="dniTransaccion")
    val acumuladorFechaTransaccion: LongAccumulator = sparkSession.sparkContext.longAccumulator( name="dniFechaTransaccion")
    val acumuladorTransaccionFull: LongAccumulator = sparkSession.sparkContext.longAccumulator( name="dniTransaccionFull")

    val dfClientes = rddSinCabecera.map(columna => {
      acumulador.add(acumulador.value +1)
      Cliente(acumulador.value, columna(4), columna(6))
    })

    val dfTransacciones = rddSinCabecera.map(columna => {
      acumuladorTransaccion.add(acumulador.value +1)
      Transaccion(acumuladorTransaccion.value, columna(2).toDouble, columna(10), "N/A", columna(3),
        Geolocalizacion(columna(5)))
    })

//Tarea 2: agrupa todos los clientes por ciudad. Contar todas las transacciones ocurridas por ciudad. HECHO
    val dfTarea2 = rddSinCabecera.map(columna => {
      acumuladorTransaccion.add(acumulador.value +1)
      Transaccion(acumuladorTransaccion.value, columna(2).toDouble, columna(10), "N/A", columna(3),
        Geolocalizacion(columna(5)))
    })

    dfTarea2.createOrReplaceGlobalTempView( viewName = "TRANSACCIONES")
    val dfOutputTarea2 = sparkSession.sql(sqlText = "Select geolocalizacion.ciudad, count(*) from " +
      "global_temp.TRANSACCIONES " +
      "group by geolocalizacion.ciudad ")
    dfOutputTarea2.show(numRows = 20)

//Tarea 3: Encuentra aquellos clientes que hayan realizado pagos superiores a 5000. HECHO.
// Se guarda el resultado en formato json
    val dfTarea3 = rddSinCabecera.map(columna => {
      acumuladorTransaccion.add(acumulador.value +1)
      Transaccion(acumuladorTransaccion.value, columna(2).toDouble, columna(10), "N/A", columna(3),
        Geolocalizacion(columna(5)))
    })

    dfTarea3.createOrReplaceGlobalTempView( viewName = "TRANSACCIONES")
    val dfOutputTarea3 = sparkSession.sql(sqlText = "Select * from global_temp.TRANSACCIONES " +
      "where importe >'5000'")
    dfOutputTarea3.write.json("/home/keepcoding/KeepCoding/Workspace/PracticaFinal/Resultado/tarea3.json")

//Tarea 4: Obtén todas las transacciones agrupada por cliente cuya ciudad sea X. HECHO
//Primero creo una clase nueva: "TransaccionFull" para poder hacer el join. Luego uno los dos datasets por
//el campo cuentaCorriente que entiendo que es único. Luego hago la consulta.
    val dfTransaccionesFull = rddSinCabecera.map(columna => {
      acumuladorTransaccionFull.add(acumulador.value +1)
      TransaccionFull(acumuladorTransaccionFull.value, columna(2).toDouble, columna(10), "N/A", columna(3), columna(6),
        Geolocalizacion(columna(5)))
    })

    val dfTarea4 = dfClientes.join(dfTransaccionesFull, "cuentaCorriente")
    dfTarea4.show(numRows = 10)

    dfTarea4.createOrReplaceGlobalTempView( viewName = "TRANSACCIONES")
    val dfOutputTarea4 = sparkSession.sql(sqlText = "Select first(nombre), first(importe), " +
      "first(descripcion), first(categoria), first(tarjetaCredito), first(geolocalizacion.ciudad)," +
      "count(cuentaCorriente) from " +
      "global_temp.TRANSACCIONES where " +
      "geolocalizacion.ciudad = 'Amsterdam' " +
      "group by cuentaCorriente" )
    dfOutputTarea4.show(numRows = 20)

//Tarea 5: Filtra todas las operaciones cuya categoría sea ocio. Guardamos el resultado en parquet. HECHO
    val dfTarea5 = rddSinCabecera.map(columna => {
      acumuladorTransaccion.add(acumulador.value +1)
      Transaccion(acumuladorTransaccion.value, columna(2).toDouble, columna(10), "N/A", columna(3),
        Geolocalizacion(columna(5)))
    })

    dfTarea5.createOrReplaceGlobalTempView( viewName = "TRANSACCIONES")
    val dfOutputTarea5 = sparkSession.sql(sqlText = "Select * from global_temp.TRANSACCIONES " +
      "where descripcion ='Cinema]' or descripcion = 'Restaurant]' or descripcion = 'Sports]'")
    dfOutputTarea5.write.parquet(path = "/home/keepcoding/KeepCoding/Workspace/PracticaFinal/Resultado/tarea5.parquet")


//Tarea 6: Obtén las últimas transacciones de cada cliente en los últimos 30 días. HECHO
//Se buscan las transacciones que sean "mayores" al 1/08/2009 y se agrupan por cuenta corriente porque es
//única. Solo puede haber una cuenta corriente. Los resultados se guardan en formato csv.
    val dfFechaTransacc = rddSinCabecera.map(columna => {
      FechaTransaccion(columna(0), columna(6))
    })

    val dfFechaTransaccCliente = dfClientes.join(dfFechaTransacc, "cuentaCorriente")

    dfFechaTransaccCliente.createOrReplaceGlobalTempView( viewName = "TRANSACCIONES")
    val dfOutput = sparkSession.sql(sqlText = "Select first(cuentaCorriente) as cuentaCorriente, " +
      "first(DNI) as DNI, first(nombre) as nombre, first(fecha) as fecha from global_temp.TRANSACCIONES " +
      "where fecha > '[1/8/09 0:01' group by cuentaCorriente" )
    dfOutput.write.csv(path = "/home/keepcoding/KeepCoding/Workspace/PracticaFinal/Resultado/tarea6.csv")

//Tarea 7[opcional]: Encontrar por cada transacción a través de su longitud y latitud cuál es el páis al que
//pertenece la transacción y guardarlo en el campo país.


  }

}
