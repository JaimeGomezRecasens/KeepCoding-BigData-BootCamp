package com.keepcoding.speedlayer

import com.keepcoding.speedlayer
import java.util.Properties
import com.keepcoding.dominio.{Cliente, Geolocalizacion, Transaccion}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.producer.{KafkaProducer, ProducerRecord}
import org.apache.spark.SparkConf
import org.apache.spark.streaming.dstream.{DStream, InputDStream}
import org.apache.spark.streaming.{Seconds, StreamingContext}
import org.apache.spark.streaming.kafka.KafkaUtils
import org.codehaus.jackson.map.deser.std.StringDeserializer

object metricassparkStreaming {

  val conf = new SparkConf().setAppName("KafkaReceiver")
  val ssc = new StreamingContext(conf, Seconds(10))

  // Nombre del tópico
  val kafkaStream = KafkaUtils.createStream(ssc, "localhost:2181", "spark-streaming-consumer-group",
    Map("spark-topic" -> 5))

  // Aquí irían las consultas
  kafkaStream.print()

  // Arrancamos Spark Streaming para comenzar con los datos
  ssc.start()
  ssc.awaitTermination()

}